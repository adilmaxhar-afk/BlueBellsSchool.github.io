
const menu = document.querySelector('.menu');
const links = document.querySelector('.nav-links');
if(menu) menu.addEventListener('click',()=>links.classList.toggle('open'));
document.querySelectorAll('.nav-links a').forEach(a=>a.addEventListener('click',()=>links.classList.remove('open')));
const forms=document.querySelectorAll('form');
forms.forEach(form=>form.addEventListener('submit',e=>{
  e.preventDefault();
  const status=form.querySelector('.form-status');
  if(status){status.textContent='Thanks. Your message has been prepared. The school can connect this form to its official email when the site is deployed.';}
}));
