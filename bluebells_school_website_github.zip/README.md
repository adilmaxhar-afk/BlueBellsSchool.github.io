# Bluebells School System Website

## Files
- `index.html` — Home
- `admission.html` — Admission
- `about.html` — About Us
- `complaints.html` — Complaints
- `events.html` — Upcoming Events
- `style.css` — Design
- `script.js` — Mobile menu + demo form behavior
- `assets/` — School images

## GitHub Pages
1. Create a GitHub repository.
2. Upload all files/folders from this project.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish.

The complaint/admission forms are front-end demos. Before the school launches the site, connect them to the school's approved email/form system.

The event photo has been privacy-protected to reduce the visibility of students' faces.
